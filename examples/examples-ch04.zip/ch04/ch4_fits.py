"""Executable evidence for Chapter 4: the complete fits() worked example.

A Python port of the Java method, an instrumented copy that records which
coverage items each execution reaches, the chapter's test tables, and the
duplicate-elimination step. Standard library only.
Run from the repository root: python3 examples/ch04/ch4_fits.py
"""

import random
import unittest

MIN_INT = -(2**31)
MAX_INT = 2**31 - 1
SUCCESS, FAILURE, ERROR = "SUCCESS", "FAILURE", "ERROR"


def fits(passengers, comfort):
    """Port of the Java method; the comments give the Java line numbers."""
    rv = FAILURE                                            # 3
    available = 120                                         # 4
    if comfort:                                             # 5
        available = available - 40                          # 6
    if passengers > 0 and passengers <= available:          # 7
        rv = SUCCESS                                        # 8
    elif passengers <= 0:                                   # 9
        rv = ERROR                                          # 10
    return rv                                               # 11


def spec(passengers, comfort):
    """Independent oracle written from the specification, not the code."""
    if passengers < 1:
        return ERROR
    limit = 80 if comfort else 120
    return SUCCESS if passengers <= limit else FAILURE


def trace(passengers, comfort):
    """Run fits() and return (result, set of coverage items reached).

    Items use the chapter's identifiers. Conditions count only when Java
    actually evaluates them (&& skips the right operand when the left is false).
    """
    items = set()
    node = {1: "SC1", 2: "SC2", 3: "SC3", 4: "SC4", 5: "SC5", 6: "SC6", 7: "SC7"}
    path = [1]
    defs = {"passengers": 1, "comfort": 1}
    rv, defs["rv"] = FAILURE, 3
    available, defs["available"] = 120, 4

    def use(var, line):
        items.add(DU_ID[(var, defs[var], line)])

    use("comfort", 5)
    items.add("CC1" if comfort else "CC2")
    if comfort:
        items.add("BC-a")
        path.append(2)
        use("available", 6)
        available, defs["available"] = available - 40, 6
        items.add("BC-c")
    else:
        items.add("BC-b")
    path.append(3)
    use("passengers", 7)
    a = passengers > 0
    items.update({"CC3", "DCC3"} if a else {"CC4", "DCC4"})
    b = None
    if a:
        use("available", 7)
        b = passengers <= available
        items.update({"CC5", "DCC5"} if b else {"CC6", "DCC6"})
    decision = a and b
    items.add("DCC1" if decision else "DCC2")
    items.add(MCC_ID[(a, b)])
    if decision:
        items.update({"BC-d", "BC-f"})
        path.append(4)
        rv, defs["rv"] = SUCCESS, 8
    else:
        items.add("BC-e")
        path.append(5)
        use("passengers", 9)
        items.add("CC7" if passengers <= 0 else "CC8")
        if passengers <= 0:
            items.update({"BC-h", "BC-i"})
            path.append(6)
            rv, defs["rv"] = ERROR, 10
        else:
            items.add("BC-g")
    path.append(7)
    use("rv", 11)
    items.update(node[n] for n in path)
    items.add(PATH_ID[tuple(path)])
    return rv, items


# Coverage items for the white-box criteria.
MCC_ID = {(True, True): "MCC1", (True, False): "MCC2", (False, None): "MCC3"}
PATH_ID = {(1, 2, 3, 4, 7): "P1", (1, 3, 4, 7): "P2", (1, 2, 3, 5, 7): "P3",
           (1, 3, 5, 7): "P4", (1, 2, 3, 5, 6, 7): "P5", (1, 3, 5, 6, 7): "P6"}
DU_ID = {("passengers", 1, 7): "DU1", ("passengers", 1, 9): "DU2",
         ("comfort", 1, 5): "DU3", ("rv", 3, 11): "DU4", ("rv", 8, 11): "DU5",
         ("rv", 10, 11): "DU6", ("available", 4, 6): "DU7",
         ("available", 4, 7): "DU8", ("available", 6, 7): "DU9"}
WB_ITEMS = ({f"SC{n}" for n in range(1, 8)} | {f"BC-{e}" for e in "abcdefghi"}
            | {f"CC{n}" for n in range(1, 9)} | {f"DCC{n}" for n in range(1, 7)}
            | set(MCC_ID.values()) | set(PATH_ID.values()) | set(DU_ID.values()))


def logical(passengers, comfort):
    """Logical values of the two line-7 conditions and the decision."""
    a = passengers > 0
    b = passengers <= (80 if comfort else 120)
    return a, b, a and b


def mcdc_pairs(tests):
    """Unique-cause independence pairs for the line-7 decision among tests."""
    found = {}
    rows = {tid: logical(p, c) for tid, (p, c, _) in tests.items()}
    for t1, (a1, b1, d1) in rows.items():
        for t2, (a2, b2, d2) in rows.items():
            if t1 < t2 and d1 != d2:
                if a1 != a2 and b1 == b2:
                    found.setdefault("A", (t1, t2))
                if b1 != b2 and a1 == a2:
                    found.setdefault("B", (t1, t2))
    return found


# Black-box tests: (passengers, comfortFlag, expected). Expected values come
# from the specification; the tests below check them against spec().
EP_TESTS = {"T1.1": (40, False, SUCCESS), "T1.2": (101, True, FAILURE),
            "T1.3": (200, False, FAILURE), "T1.4": (-100, False, ERROR)}
BV_TESTS = {"T2.1": (1, False, SUCCESS), "T2.2": (80, True, SUCCESS),
            "T2.3": (81, False, SUCCESS), "T2.4": (120, True, FAILURE),
            "T2.5": (121, True, FAILURE), "T2.6": (MAX_INT, True, FAILURE),
            "T2.7": (MIN_INT, False, ERROR), "T2.8": (0, False, ERROR)}
BV_PAIRED = {"T2.9": (81, True, FAILURE), "T2.10": (120, False, SUCCESS),
             "T2.11": (121, False, FAILURE)}
TT_TESTS = {"T3.1": (200, False, FAILURE), "T3.2": (100, False, SUCCESS),
            "T3.3": (100, True, FAILURE), "T3.4": (40, False, SUCCESS)}

SEED = 4


def random_tests(n=10, seed=SEED):
    """Pick the result first, then the flag, then a passenger count that gives it."""
    rng = random.Random(seed)
    tests = {}
    for k in range(1, n + 1):
        result = rng.choice([SUCCESS, FAILURE, ERROR])
        comfort = rng.choice([False, True])
        limit = 80 if comfort else 120
        low, high = {SUCCESS: (1, limit), FAILURE: (limit + 1, MAX_INT),
                     ERROR: (MIN_INT, 0)}[result]
        tests[f"T4.{k}"] = (rng.randint(low, high), comfort, result)
    return tests


RT_TESTS = random_tests()

# White-box tests. Inputs come from the CFG; expected values from the spec.
SC_TESTS = {"T5.1": (40, False, SUCCESS), "T5.2": (-100, True, ERROR)}
BC_TESTS = {"T6.1": (40, False, SUCCESS), "T6.2": (-100, True, ERROR),
            "T6.3": (200, False, FAILURE)}
CC_TESTS = {"T7.1": (-100, False, ERROR), "T7.2": (101, True, FAILURE),
            "T7.3": (40, True, SUCCESS)}
DCC_TESTS = {"T8.1": (40, True, SUCCESS), "T8.2": (-100, False, ERROR),
             "T8.3": (200, False, FAILURE)}
MCC_TESTS = {"T9.1": (40, False, SUCCESS), "T9.2": (200, False, FAILURE),
             "T9.3": (-100, False, ERROR)}
MCDC_TESTS = {"T10.1": (-100, False, ERROR), "T10.2": (100, False, SUCCESS),
              "T10.3": (100, True, FAILURE)}
PATH_TESTS = {"T11.1": (40, True, SUCCESS), "T11.2": (40, False, SUCCESS),
              "T11.3": (101, True, FAILURE), "T11.4": (200, False, FAILURE),
              "T11.5": (-100, True, ERROR), "T11.6": (-100, False, ERROR)}
DU_TESTS = {"T12.1": (40, False, SUCCESS), "T12.2": (101, True, FAILURE),
            "T12.3": (-100, False, ERROR)}

BLACK_BOX = [EP_TESTS, BV_TESTS, BV_PAIRED, TT_TESTS, RT_TESTS]
WHITE_BOX = [SC_TESTS, BC_TESTS, CC_TESTS, DCC_TESTS, MCC_TESTS, MCDC_TESTS,
             PATH_TESTS, DU_TESTS]
SYSTEMATIC = [EP_TESTS, BV_TESTS, BV_PAIRED, TT_TESTS]


def merge(groups):
    out = {}
    for g in groups:
        out.update(g)
    return out


def eliminate_identical(groups):
    """Keep the first test for each input pair; report what each one replaces."""
    kept, replaced = {}, {}
    seen = {}
    for tid, (p, c, exp) in merge(groups).items():
        if (p, c) in seen:
            replaced.setdefault(seen[(p, c)], []).append(tid)
        else:
            seen[(p, c)] = tid
            kept[tid] = (p, c, exp)
    return kept, replaced


def covered(tests):
    items = set()
    for p, c, _ in tests.values():
        items |= trace(p, c)[1]
    return items


def mutants():
    """Small single changes to fits(); each returns a function."""
    def make(avail=120, cut=40, gt0=lambda p: p > 0, le=lambda p, a: p <= a,
             err=lambda p: p <= 0):
        def m(p, c):
            rv, a = FAILURE, avail
            if c:
                a = a - cut
            if gt0(p) and le(p, a):
                rv = SUCCESS
            elif err(p):
                rv = ERROR
            return rv
        return m
    return {"M1 seats 121": make(avail=121), "M2 cut 39": make(cut=39),
            "M3 cut 41": make(cut=41), "M4 p >= 0": make(gt0=lambda p: p >= 0),
            "M5 p < seats": make(le=lambda p, a: p < a),
            "M6 p < 0 error": make(err=lambda p: p < 0)}


def killers(tests, mutant):
    return sorted(t for t, (p, c, exp) in tests.items() if mutant(p, c) != exp)


class FitsChecks(unittest.TestCase):
    def test_every_expected_value_matches_the_specification(self):
        for tid, (p, c, exp) in merge(BLACK_BOX + WHITE_BOX).items():
            self.assertEqual(spec(p, c), exp, tid)
            self.assertEqual(fits(p, c), exp, tid)

    def test_port_matches_spec_on_a_dense_grid(self):
        for p in list(range(-5, 200)) + [MIN_INT, MAX_INT]:
            for c in (False, True):
                self.assertEqual(fits(p, c), spec(p, c))
                self.assertEqual(trace(p, c)[0], spec(p, c))

    def test_random_data_is_reproducible(self):
        self.assertEqual(random_tests(), RT_TESTS)
        self.assertEqual([v[:2] for v in RT_TESTS.values()][:3],
                         [(14, True), (-90716605, True), (9, False)])
        self.assertEqual(RT_TESTS["T4.10"], (40, False, SUCCESS))  # repeats T1.1

    def test_each_white_box_set_meets_its_own_criterion(self):
        want = [(SC_TESTS, "SC"), (BC_TESTS, "BC-"), (CC_TESTS, "CC"),
                (DCC_TESTS, "DCC"), (MCC_TESTS, "MCC"), (PATH_TESTS, "P"),
                (DU_TESTS, "DU")]
        for tests, prefix in want:
            goal = {i for i in WB_ITEMS if i.rstrip("0123456789") == prefix
                    or (prefix == "BC-" and i.startswith("BC-"))}
            self.assertTrue(goal, prefix)
            self.assertLessEqual(goal, covered(tests), prefix)
        self.assertEqual(set(mcdc_pairs(MCDC_TESTS)), {"A", "B"})

    def test_slide_condition_set_misses_an_evaluated_outcome(self):
        two = {k: CC_TESTS[k] for k in ("T7.1", "T7.2")}
        self.assertNotIn("CC5", covered(two))     # -100 skips the right operand
        self.assertIn("CC5", covered(CC_TESTS))

    def test_identical_input_elimination(self):
        kept, replaced = eliminate_identical(BLACK_BOX + WHITE_BOX)
        self.assertEqual(replaced["T1.1"], ["T3.4", "T4.10", "T5.1", "T6.1",
                                            "T9.1", "T11.2", "T12.1"])
        self.assertEqual(replaced["T1.2"], ["T7.2", "T11.3", "T12.2"])
        self.assertEqual(replaced["T1.3"], ["T3.1", "T6.3", "T8.3", "T9.2", "T11.4"])
        self.assertEqual(replaced["T1.4"], ["T7.1", "T8.2", "T9.3", "T10.1", "T11.6",
                                            "T12.3"])
        self.assertEqual(replaced["T3.2"], ["T10.2"])
        self.assertEqual(replaced["T3.3"], ["T10.3"])
        self.assertEqual(replaced["T5.2"], ["T6.2", "T11.5"])
        self.assertEqual(replaced["T7.3"], ["T8.1", "T11.1"])
        self.assertEqual(len(merge(BLACK_BOX + WHITE_BOX)), 55)
        self.assertEqual(len(kept), 28)

    def test_systematic_black_box_tests_cover_every_white_box_item(self):
        bb, _ = eliminate_identical(SYSTEMATIC)
        self.assertEqual((len(bb), len(WB_ITEMS)), (17, 48))
        self.assertEqual(WB_ITEMS - covered(bb), {"P5"})     # comfort on, then ERROR
        self.assertEqual(set(mcdc_pairs(bb)), {"A", "B"})
        final = dict(bb, **{"T5.2": SC_TESTS["T5.2"]})
        self.assertEqual(WB_ITEMS - covered(final), set())
        self.assertLessEqual(trace(40, True)[1], covered(bb))  # T7.3 adds nothing

    def test_paired_boundaries_kill_mutants_the_slide_suite_misses(self):
        slide_bb = merge([EP_TESTS, BV_TESTS, TT_TESTS])
        paired = merge(SYSTEMATIC)
        white = merge(WHITE_BOX)
        survive_slide = {n for n, m in mutants().items() if not killers(slide_bb, m)}
        self.assertEqual(survive_slide, {"M1 seats 121", "M2 cut 39"})
        self.assertEqual({n for n, m in mutants().items() if not killers(paired, m)},
                         set())
        self.assertEqual(killers(paired, mutants()["M1 seats 121"]), ["T2.11", "T2.9"])
        self.assertEqual(killers(paired, mutants()["M2 cut 39"]), ["T2.9"])
        survive_white = {n for n, m in mutants().items() if not killers(white, m)}
        self.assertEqual(survive_white, set(mutants()))      # white-box data kills none
        self.assertEqual({n for n, m in mutants().items() if killers(RT_TESTS, m)},
                         set())

    def test_random_mix_and_final_suite_size(self):
        results = [v[2] for v in RT_TESTS.values()]
        self.assertEqual([results.count(r) for r in (SUCCESS, FAILURE, ERROR)], [6, 1, 3])
        kept, _ = eliminate_identical(BLACK_BOX + WHITE_BOX)
        del kept["T7.3"]                         # covers nothing the others miss
        self.assertEqual(len(kept), 27)          # 17 systematic + T5.2 + 9 random

    def test_item_breakdown_and_random_path_p5(self):
        counts = [len([i for i in WB_ITEMS if i.rstrip("0123456789") == p])
                  for p in ("SC", "BC-", "CC", "DCC", "MCC", "P", "DU")]
        counts[1] = len([i for i in WB_ITEMS if i.startswith("BC-")])
        self.assertEqual(counts, [7, 9, 8, 6, 3, 6, 9])      # 48 items in all
        # Random tests reach P5 only by chance, so step 2 gives them no credit.
        p5 = sorted(t for t, (p, c, _) in RT_TESTS.items() if "P5" in trace(p, c)[1])
        self.assertEqual(p5, ["T4.2", "T4.6", "T4.9"])

    def test_paired_boundaries_add_no_white_box_item(self):
        base, _ = eliminate_identical([EP_TESTS, BV_TESTS, TT_TESTS])
        self.assertEqual(covered(BV_PAIRED) - covered(base), set())

    def test_exercise_answers(self):
        def spec150(p, c):                       # E1: 150 seats, comfort removes 50
            if p < 1:
                return ERROR
            return SUCCESS if p <= (100 if c else 150) else FAILURE
        changed = sorted(t for t, (p, c, e) in merge(SYSTEMATIC).items()
                         if spec150(p, c) != e)
        self.assertEqual(changed, ["T2.11", "T2.9", "T3.3"])

        slides = [EP_TESTS, BV_TESTS, TT_TESTS, RT_TESTS] + WHITE_BOX   # E4: no T2.9-T2.11
        kept, _ = eliminate_identical(slides)
        self.assertEqual(len(kept), 25)
        del kept["T7.3"]
        self.assertEqual(WB_ITEMS - covered(kept), set())
        self.assertEqual({n for n, m in mutants().items() if not killers(kept, m)},
                         {"M1 seats 121", "M2 cut 39"})

        def nested(p, c):                        # E3: line 7 split into nested ifs
            rv, seats = FAILURE, 120 - (40 if c else 0)
            if p > 0:
                if p <= seats:
                    rv = SUCCESS
            else:
                rv = ERROR
            return rv
        for p in list(range(-3, 200)) + [MIN_INT, MAX_INT]:
            for c in (False, True):
                self.assertEqual(nested(p, c), spec(p, c))


if __name__ == "__main__":
    unittest.main(verbosity=1)
