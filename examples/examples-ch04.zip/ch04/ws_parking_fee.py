"""Executable evidence for the Chapter 4 worked example in the student worksheets.

parking_fee() under contract W4, an instrumented copy that records which
coverage items each execution reaches, the worksheet's test tables, the
two-step duplicate elimination, and three mutants. Standard library only.
Run from the repository root: python3 examples/ch04/ws_parking_fee.py
"""

import random
import unittest

ERROR = "ValueError"


def parking_fee(minutes, resident=False):
    """The code under test; the comments give the worksheet line numbers."""
    if minutes < 0:                                         # 2
        raise ValueError("minutes must be at least 0")      # 3
    fee = 1000                                              # 4
    if minutes <= 30 or resident:                           # 5
        fee = 0                                             # 6
    elif minutes <= 120:                                    # 7
        fee = 500                                           # 8
    return fee                                              # 9


def spec(minutes, resident):
    """Independent oracle written from W4, not from the code."""
    if minutes < 0:
        return ERROR
    if minutes <= 30 or resident:
        return 0
    return 500 if minutes <= 120 else 1000


def trace(minutes, resident, mutant=None):
    """Return (result, coverage items reached). A and B are evaluated conditions."""
    items = {"SC2", "DU1"}
    if minutes < 0:
        return ERROR, items | {"SC3", "BC2T", "CC1", "P1"}
    items |= {"SC4", "SC5", "BC2F", "CC2", "DU2"}
    a = minutes < 30 if mutant == "M1" else minutes <= 30
    items |= {"CC3", "DCC3"} if a else {"CC4", "DCC4", "DU4"}
    if not a:
        items |= {"CC5", "DCC5"} if resident else {"CC6", "DCC6"}
    items.add("MCC_" + "TF"[not a] + "TF"[not resident])     # logical A, B
    decision = (a and resident) if mutant == "M3" else (a or resident)
    items.add("DCC1" if decision else "DCC2")
    if decision:
        fee, path, du = 0, "P2", "DU6"
        items |= {"BC5T", "SC6"}
    else:
        items |= {"BC5F", "SC7", "DU3"}
        c = minutes < 120 if mutant == "M2" else minutes <= 120
        items.add("CC7" if c else "CC8")
        if c:
            fee, path, du = 500, "P3", "DU7"
            items |= {"BC7T", "SC8"}
        else:
            fee, path, du = 1000, "P4", "DU5"
            items.add("BC7F")
    return fee, items | {"SC9", path, du}


def mcdc(inputs):
    """MC/DC pairs for line 5: A from TF to FF, B from FF to FT."""
    combos = set().union(*(trace(*x)[1] for x in inputs))
    pairs = set()
    if {"MCC_TF", "MCC_FF"} <= combos:
        pairs.add("MCDC_A")
    if {"MCC_FF", "MCC_FT"} <= combos:
        pairs.add("MCDC_B")
    return pairs


def random_rows(n=4, seed=7):
    """Pick the result first, then resident, then minutes that must give it."""
    rng = random.Random(seed)
    for k in range(1, n + 1):
        result = rng.choice([0, 500, 1000, ERROR])
        resident = rng.choice([False, True]) if result in (0, ERROR) else False
        low, high = {0: (0, 1440) if resident else (0, 30), 500: (31, 120),
                     1000: (121, 1440), ERROR: (-1440, -1)}[result]
        yield f"T4.{k}", rng.randint(low, high), resident, result


F, T = False, True
BLACK_BOX = [
    ("T1.1", 10, T), ("T1.2", 60, F), ("T1.3", 200, F), ("T1.4", -5, F),
    ("T2.1", 0, F), ("T2.2", 30, T), ("T2.3", 31, F), ("T2.4", 120, T),
    ("T2.5", 121, F), ("T2.6", -1, F), ("T2.7", 30, F), ("T2.8", 120, F),
    ("T3.1", 10, F), ("T3.2", 60, F), ("T3.3", 60, T), ("T3.4", 200, F),
] + [row[:3] for row in random_rows()]
WHITE_BOX = [
    ("T5.1", -5, T), ("T5.2", 10, F), ("T5.3", 60, F),
    ("T6.1", -5, T), ("T6.2", 10, F), ("T6.3", 60, F), ("T6.4", 500, F),
    ("T7.1", -5, T), ("T7.2", 10, F), ("T7.3", 90, T), ("T7.4", 60, F), ("T7.5", 500, F),
    ("T8.1", 10, F), ("T8.2", 90, T), ("T8.3", 60, F),
    ("T9.1", 10, T), ("T9.2", 10, F), ("T9.3", 90, T), ("T9.4", 60, F),
    ("T10.1", 10, F), ("T10.2", 60, F), ("T10.3", 90, T),
    ("T11.1", -5, T), ("T11.2", 10, F), ("T11.3", 60, F), ("T11.4", 500, F),
    ("T12.1", 60, F), ("T12.2", 10, F), ("T12.3", 500, F),
]
ALL = BLACK_BOX + WHITE_BOX


def group(test_id):
    return int(test_id[1:].split(".")[0])


def step1():
    """Keep the first test with each input; return {input: id}, {kept: [replaced]}."""
    kept, replaced = {}, {}
    for test_id, m, r in ALL:
        if (m, r) in kept:
            replaced.setdefault(kept[(m, r)], []).append(test_id)
        else:
            kept[(m, r)] = test_id
    return kept, replaced


class WorkedExample(unittest.TestCase):
    def test_code_matches_contract(self):
        for m in range(-3, 1500):
            for r in (F, T):
                try:
                    actual = parking_fee(m, r)
                except ValueError:
                    actual = ERROR
                self.assertEqual(actual, spec(m, r))
                self.assertEqual(trace(m, r)[0], actual)

    def test_random_rows(self):
        self.assertEqual([row[1:] for row in random_rows()],
                         [(429, F, 1000), (-1292, F, ERROR), (1193, T, 0), (1, F, 0)])

    def test_counts(self):
        self.assertEqual((len(BLACK_BOX), len(WHITE_BOX), len(ALL)), (20, 29, 49))
        items = set().union(*(trace(m, r)[1] for _, m, r in ALL)) | mcdc(
            [(m, r) for _, m, r in ALL])
        # 8 SC + 6 BC + 8 CC + 6 DCC + 4 MCC + 2 MC/DC + 4 paths + 7 DU
        self.assertEqual(len(items), 45)

    def test_elimination(self):
        kept, replaced = step1()
        self.assertEqual(len(kept), 21)
        self.assertEqual(replaced, {
            "T1.1": ["T9.1"],
            "T1.2": ["T3.2", "T5.3", "T6.3", "T7.4", "T8.3", "T9.4", "T10.2",
                     "T11.3", "T12.1"],
            "T1.3": ["T3.4"],
            "T3.1": ["T5.2", "T6.2", "T7.2", "T8.1", "T9.2", "T10.1", "T11.2",
                     "T12.2"],
            "T5.1": ["T6.1", "T7.1", "T11.1"],
            "T6.4": ["T7.5", "T11.4", "T12.3"],
            "T7.3": ["T8.2", "T9.3", "T10.3"],
        })
        systematic = [x for x, i in kept.items() if group(i) <= 3]
        self.assertEqual(len(systematic), 14)
        covered = set().union(*(trace(*x)[1] for x in systematic)) | mcdc(systematic)
        white = {i: x for x, i in kept.items() if group(i) >= 5}
        self.assertEqual(sorted(white), ["T5.1", "T6.4", "T7.3"])
        for x in white.values():
            self.assertLessEqual(trace(*x)[1], covered)  # step 2 removes all three
        self.assertEqual(len(kept) - len(white), 18)

    def test_mutants(self):
        kept, _ = step1()
        final = [(i, m, r) for (m, r), i in kept.items() if group(i) <= 4]
        killers = {mut: [i for i, m, r in final if trace(m, r, mut)[0] != spec(m, r)]
                   for mut in ("M1", "M2", "M3")}
        self.assertEqual(killers["M1"], ["T2.7"])
        self.assertEqual(killers["M2"], ["T2.8"])
        self.assertEqual(killers["M3"], ["T2.1", "T2.4", "T2.7", "T3.1", "T3.3",
                                         "T4.3", "T4.4"])
        for mut in ("M1", "M2"):  # no white-box test kills the boundary mutants
            self.assertFalse([i for i, m, r in WHITE_BOX
                              if trace(m, r, mut)[0] != spec(m, r)])


if __name__ == "__main__":
    unittest.main(verbosity=2)
