"""Ten reproducible random tests: pick the result, then the flag, then the input."""
import random

import pytest

from airline.fits import Status, fits

SEED = 4
MIN_INT, MAX_INT = -(2**31), 2**31 - 1


def generate(n=10, seed=SEED):
    rng = random.Random(seed)
    for k in range(1, n + 1):
        result = rng.choice(["SUCCESS", "FAILURE", "ERROR"])
        comfort = rng.choice([False, True])
        limit = 80 if comfort else 120
        low, high = {"SUCCESS": (1, limit), "FAILURE": (limit + 1, MAX_INT),
                     "ERROR": (MIN_INT, 0)}[result]
        yield f"T4.{k}", rng.randint(low, high), comfort, Status(result)


ROWS = list(generate())


@pytest.mark.parametrize("passengers, comfort_flag, expected",
                         [r[1:] for r in ROWS], ids=[r[0] for r in ROWS])
def test_random(passengers, comfort_flag, expected):
    assert fits(passengers, comfort_flag) is expected
