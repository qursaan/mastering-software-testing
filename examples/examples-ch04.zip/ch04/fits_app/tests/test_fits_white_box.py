"""The one white-box test the black-box suite did not already supply."""
from airline.fits import Status, fits


def test_t5_2_comfort_then_error_path_p5():
    assert fits(-100, True) is Status.ERROR
