"""Systematic black-box tests for fits(), duplicates removed."""
import pytest

from airline.fits import Status, fits

S, F, E = Status.SUCCESS, Status.FAILURE, Status.ERROR
MIN_INT, MAX_INT = -(2**31), 2**31 - 1

CASES = [  # id, passengers, comfort_flag, expected (from spec)
    ("T1.1", 40, False, S),       ("T1.2", 101, True, F),
    ("T1.3", 200, False, F),      ("T1.4", -100, False, E),
    ("T2.1", 1, False, S),        ("T2.2", 80, True, S),
    ("T2.3", 81, False, S),       ("T2.4", 120, True, F),
    ("T2.5", 121, True, F),       ("T2.6", MAX_INT, True, F),
    ("T2.7", MIN_INT, False, E),  ("T2.8", 0, False, E),
    ("T2.9", 81, True, F),        ("T2.10", 120, False, S),
    ("T2.11", 121, False, F),     ("T3.2", 100, False, S),
    ("T3.3", 100, True, F),
]


@pytest.mark.parametrize("passengers, comfort_flag, expected",
                         [c[1:] for c in CASES],
                         ids=[c[0] for c in CASES])
def test_fits(passengers, comfort_flag, expected):
    assert fits(passengers, comfort_flag) is expected
