"""Python port of the Chapter 4 Java method fits()."""
from enum import Enum


class Status(Enum):
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"
    ERROR = "ERROR"


def fits(passengers, comfort_flag):
    """Can this many passengers fly on the 120-seat charter plane?"""
    rv = Status.FAILURE
    available_seats = 120
    if comfort_flag:
        available_seats = available_seats - 40
    if passengers > 0 and passengers <= available_seats:
        rv = Status.SUCCESS
    elif passengers <= 0:
        rv = Status.ERROR
    return rv
