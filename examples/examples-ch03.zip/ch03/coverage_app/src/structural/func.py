"""Python port of the Chapter 3 Java method func(a, b)."""


def func(a, b):
    """Return 100 / a when a > 10 or b == 0, otherwise 100."""
    x = 100
    if a > 10 or b == 0:
        x = int(x / a)  # truncate towards zero, as Java does
    return x
