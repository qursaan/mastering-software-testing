"""Step 2: take the false branch of the decision (the missing else)."""
from structural.func import func


def test_bc_false_keeps_100():
    assert func(5, 1) == 100
