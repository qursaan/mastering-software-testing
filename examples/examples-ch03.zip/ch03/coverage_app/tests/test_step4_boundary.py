"""Step 4: a boundary test from the specification, not from coverage."""
from structural.func import func


def test_bv_a_equals_10_does_not_divide():
    assert func(10, 1) == 100
