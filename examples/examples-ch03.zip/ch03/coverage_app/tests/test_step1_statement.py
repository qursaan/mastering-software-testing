"""Step 1: one test executes every statement."""
from structural.func import func


def test_sc1_divide_when_a_is_large():
    assert func(50, 1) == 2
