"""Step 3: make b == 0 evaluate true (with a > 10 false)."""
from structural.func import func


def test_cc_b_zero_divides():
    assert func(5, 0) == 20
