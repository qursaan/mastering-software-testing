"""Executable evidence for Chapter 3, using only the Python standard library.

These are teaching ports, not execution or instrumentation of Java code.
Inputs in the worked cases fit Java's int domain. java_quotient preserves
truncation toward zero for the fixed numerator 100; this is not a complete
Java integer arithmetic emulator. Null/overflow contracts are out of scope.
Run from the repository root: python3 examples/ch03/ch3_unit_techniques.py
"""

import unittest
from dataclasses import dataclass

MIN_INT = -(2**31)
MAX_INT = 2**31 - 1


def discount(qty, member):
    """Percentage discount for integer quantity and boolean membership."""
    if qty < 1 or qty > 100:
        return -1
    base = 10 if qty >= 10 else 0
    return base + (5 if member else 0)


@dataclass
class Account:
    """The slides' extended state model, with explicit teaching state."""

    locked: bool = False
    failures: int = 0

    def login(self, correct):
        if self.locked:
            return "LOCKED"
        if correct:
            self.failures = 0
            return "OK"
        if self.failures == 2:
            self.locked = True
            return "LOCKED"
        self.failures += 1
        return "FAIL"

    def unlock(self):
        if self.locked:
            self.locked = False
            self.failures = 0


def java_quotient(numerator, denominator):
    """Truncate an integer quotient toward zero, without a float conversion."""
    magnitude = abs(numerator) // abs(denominator)
    return -magnitude if (numerator < 0) != (denominator < 0) else magnitude


def func(a, b):
    x = 100
    if (a > 10) or (b == 0):
        x = java_quotient(x, a)
    return x


def condition_trace(a, b):
    """Return logical A/B, evaluated B (None if skipped), and decision."""
    a_value, b_value = a > 10, b == 0
    evaluated_b = None if a_value else b_value
    return a_value, b_value, evaluated_b, a_value or b_value


def mutant(a, b, name):
    """Apply exactly one of the five chapter mutations."""
    if name not in {"M1", "M2", "M3", "M4", "M5"}:
        raise ValueError(name)
    left = a >= 10 if name == "M2" else a > 10
    right = b != 0 if name == "M3" else b == 0
    decision = left and right if name == "M1" else left or right
    if decision:
        if name == "M4":
            return 100
        if name == "M5":
            return 100 * a
        return java_quotient(100, a)
    return 100


def sum_with_du(values):
    """Trace local-variable node-use pairs using the listing's line numbers.

    The current definition is replaced after RHS reads. Predicate uses count
    at node 4 rather than separately on its two outgoing edges. The parameter
    and array contents are deliberately not part of the pair denominator.
    """
    pairs = set()
    definitions = {}

    def define(variable, line):
        definitions[variable] = line

    def use(variable, line):
        pairs.add((variable, definitions[variable], line))

    total = 0
    define("total", 2)
    i = 0
    define("i", 3)
    while True:
        use("i", 4)
        if not i < len(values):
            break
        use("total", 5)
        use("i", 5)
        total = total + values[i]
        define("total", 5)
        use("i", 6)
        i = i + 1
        define("i", 6)
    use("total", 8)
    return total, pairs


# Independent expected values from the chapter contract, not func/discount.
EP_CASES = [
    (5, True, 5), (50, False, 10), (5, False, 0),
    (50, True, 15), (-10, True, -1), (500, False, -1),
]
ENDPOINT_CASES = [
    (MIN_INT, True, -1), (0, True, -1), (1, True, 5),
    (9, False, 0), (10, True, 15), (100, False, 10),
    (101, False, -1), (MAX_INT, False, -1),
]
THRESHOLD_CASES = [(9, True, 5), (10, False, 10)]
MUTATION_ROWS = [
    # a, b, specified result, mutants killed by that exact assertion
    (50, 1, 2, {"M1", "M4", "M5"}),
    (5, 1, 100, {"M3"}),
    (5, 0, 20, {"M1", "M3", "M4", "M5"}),
    (10, 1, 100, {"M2", "M3"}),
]
MUTANTS = ("M1", "M2", "M3", "M4", "M5")
DU_ITEMS = {
    ("total", 2, 5), ("total", 2, 8),
    ("total", 5, 5), ("total", 5, 8),
    ("i", 3, 4), ("i", 3, 5), ("i", 3, 6),
    ("i", 6, 4), ("i", 6, 5), ("i", 6, 6),
}


class ChapterEvidence(unittest.TestCase):
    def test_discount_partition_boundary_and_interaction_cases(self):
        cases = EP_CASES + ENDPOINT_CASES + THRESHOLD_CASES
        self.assertEqual(len({(q, m) for q, m, _ in cases}), 16)
        for qty, member, expected in cases:
            with self.subTest(qty=qty, member=member):
                self.assertEqual(discount(qty, member), expected)

    def test_discount_properties_need_exact_oracles(self):
        # Exhaust this small valid domain; the chapter's random experiment
        # remains an exercise rather than an unrecorded random run.
        for qty in range(1, 101):
            self.assertEqual(discount(qty, True) - discount(qty, False), 5)
        bad_discount = lambda qty, member: 6 if member else 1
        self.assertEqual(bad_discount(5, True) - bad_discount(5, False), 5)
        self.assertNotEqual(bad_discount(5, False), 0)

    def test_login_reset_lock_and_unlock(self):
        account = Account()
        sequence = [
            (False, "FAIL", 1, False), (False, "FAIL", 2, False),
            (True, "OK", 0, False), (False, "FAIL", 1, False),
            (False, "FAIL", 2, False), (False, "LOCKED", 2, True),
            (True, "LOCKED", 2, True), (False, "LOCKED", 2, True),
        ]
        for correct, result, failures, locked in sequence:
            self.assertEqual(account.login(correct), result)
            self.assertEqual((account.failures, account.locked), (failures, locked))
        account.unlock()
        self.assertEqual((account.failures, account.locked), (0, False))
        self.assertEqual(account.login(True), "OK")
        for result in ("FAIL", "FAIL", "LOCKED"):
            self.assertEqual(account.login(False), result)

    def test_active_unlock_preserves_failure_history(self):
        account = Account()
        self.assertEqual(account.login(False), "FAIL")
        self.assertEqual(account.login(False), "FAIL")
        account.unlock()
        self.assertEqual((account.failures, account.locked), (2, False))
        self.assertEqual(account.login(False), "LOCKED")

    def test_truth_rows_and_evaluated_condition_denominator(self):
        expected_rows = [
            ((50, 1), (True, False, None, True)),
            ((5, 0), (False, True, True, True)),
            ((5, 1), (False, False, False, False)),
            ((50, 0), (True, True, None, True)),
        ]
        for args, expected in expected_rows:
            self.assertEqual(condition_trace(*args), expected)
        outcomes = set()
        decisions = set()
        for args in [(50, 1), (5, 0)]:
            a, _, evaluated_b, decision = condition_trace(*args)
            outcomes.add(("A", a))
            if evaluated_b is not None:
                outcomes.add(("B", evaluated_b))
            decisions.add(decision)
        self.assertEqual(outcomes, {("A", True), ("A", False), ("B", True)})
        self.assertEqual(decisions, {True})
        # Check the two logical independent-effect pairs explicitly.
        rows = [condition_trace(*args) for args in [(50, 1), (5, 1), (5, 0)]]
        self.assertEqual(rows[0][1], rows[1][1])
        self.assertNotEqual(rows[0][0], rows[1][0])
        self.assertNotEqual(rows[0][3], rows[1][3])
        self.assertEqual(rows[1][0], rows[2][0])
        self.assertNotEqual(rows[1][1], rows[2][1])
        self.assertNotEqual(rows[1][3], rows[2][3])

    def test_arithmetic_and_exception_scope(self):
        for a, b, expected in [(50, 0, 2), (-6, 0, -16), (0, 1, 100)]:
            self.assertEqual(func(a, b), expected)
        # Python's model exception corresponds to the Java zero-divisor
        # observation; neither supplies the missing product requirement.
        with self.assertRaises(ZeroDivisionError):
            func(0, 0)

    def test_definition_use_pairs(self):
        empty_sum, empty_pairs = sum_with_du([])
        two_sum, two_pairs = sum_with_du([7, 3])
        one_sum, one_pairs = sum_with_du([7])
        self.assertEqual((empty_sum, one_sum, two_sum), (0, 7, 10))
        self.assertEqual(empty_pairs, {("total", 2, 8), ("i", 3, 4)})
        self.assertEqual(two_pairs, DU_ITEMS - {("total", 2, 8)})
        self.assertEqual(empty_pairs | two_pairs, DU_ITEMS)
        self.assertEqual((empty_pairs | two_pairs) | one_pairs, DU_ITEMS)
        self.assertNotIn(("total", 5, 5), one_pairs)
        self.assertNotIn(("i", 6, 6), one_pairs)

    def test_mutation_matrix_and_weak_oracle(self):
        killed_so_far = set()
        scores = []
        for a, b, expected, expected_kills in MUTATION_ROWS:
            self.assertEqual(func(a, b), expected)
            actual_kills = {m for m in MUTANTS if mutant(a, b, m) != expected}
            self.assertEqual(actual_kills, expected_kills)
            killed_so_far |= actual_kills
            scores.append(len(killed_so_far))
            for name in MUTANTS:
                self.assertGreaterEqual(mutant(a, b, name), 0)
        self.assertEqual(scores, [3, 4, 4, 5])
        self.assertEqual(mutant(50, 0, "M2"), 2)  # Logical MCC still misses M2.


if __name__ == "__main__":
    unittest.main(verbosity=2)
