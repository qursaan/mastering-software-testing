"""Teaching checkout package for Chapter 1."""
