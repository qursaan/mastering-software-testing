"""Delivery-fee rule R1-R2 from the checkout contract."""


def delivery_fee(quantity, member):
    """Return the delivery fee in cents for a valid order.

    R1: quantity must be an integer from 1 through 100, else ValueError.
    R2: members, or orders of at least 10 items, pay 0; others pay 500.
    """
    if quantity < 1 or quantity > 100:
        raise ValueError("quantity must be between 1 and 100")
    if member or quantity >= 10:
        return 0
    return 500
