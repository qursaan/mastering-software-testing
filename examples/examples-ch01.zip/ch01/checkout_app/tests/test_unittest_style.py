"""Chapter 1 sidebar: the same checks written with the standard unittest module."""
import unittest

from checkout.fees import delivery_fee


class DeliveryFeeTest(unittest.TestCase):
    def test_small_order_pays_standard_fee(self):
        self.assertEqual(delivery_fee(2, False), 500)

    def test_ten_items_get_free_delivery(self):
        self.assertEqual(delivery_fee(10, False), 0)

    def test_zero_items_are_rejected(self):
        with self.assertRaises(ValueError):
            delivery_fee(0, False)


if __name__ == "__main__":
    unittest.main()
