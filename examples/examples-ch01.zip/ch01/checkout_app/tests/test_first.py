"""Chapter 1: first test functions for delivery_fee (R1 and R2)."""
import pytest

from checkout.fees import delivery_fee


def test_small_order_pays_standard_fee():
    # Arrange: inputs and the expected value taken from R2, not from the code
    quantity, member, expected = 2, False, 500
    # Act: call the unit under test
    actual = delivery_fee(quantity, member)
    # Assert: compare the observation with the oracle
    assert actual == expected


def test_ten_items_get_free_delivery():
    assert delivery_fee(10, False) == 0


def test_zero_items_are_rejected():
    with pytest.raises(ValueError):
        delivery_fee(0, False)
