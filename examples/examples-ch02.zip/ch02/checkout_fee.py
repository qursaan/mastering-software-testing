"""Runnable Chapter 2 checkout example. Run with Python 3; no packages needed."""


# Contract: integer quantity and Boolean membership are supplied by the caller.
def delivery_fee(quantity, member):
    """Return cents; reject invalid quantities before applying benefits."""
    if quantity < 1 or quantity > 100:
        raise ValueError("quantity must be between 1 and 100")
    if member or quantity >= 10:
        return 0
    return 500


VALID_CASES = [
    ("T02", 1, False, 500), ("T03", 2, False, 500),
    ("T04", 9, False, 500), ("T05", 10, False, 0),
    ("T06", 11, False, 0), ("T07", 99, False, 0),
    ("T08", 100, False, 0), ("T10", 1, True, 0),
    ("T11", 100, True, 0),
]
REJECTED_CASES = [
    ("T01", 0, False), ("T09", 101, False),
    ("T12", 0, True), ("T13", 101, True),
]


def run_checks(fee=delivery_fee):
    for test_id, quantity, member, expected in VALID_CASES:
        actual = fee(quantity, member)
        if actual != expected:
            raise AssertionError(
                f"{test_id}: expected {expected} cents, got {actual}")
    for test_id, quantity, member in REJECTED_CASES:
        try:
            fee(quantity, member)
        except ValueError:
            pass
        else:
            raise AssertionError(f"{test_id}: expected ValueError")


if __name__ == "__main__":
    run_checks()
    print(f"{len(VALID_CASES) + len(REJECTED_CASES)} checkout checks passed")
