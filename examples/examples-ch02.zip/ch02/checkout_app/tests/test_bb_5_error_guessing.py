"""Technique 5: error guessing from likely mistakes."""
import pytest

from checkout.fees import delivery_fee


def test_eg1_strict_comparison_at_ten():          # guess: '>' instead of '>='
    assert delivery_fee(10, False) == 0


def test_eg2_member_cannot_bypass_validation():   # guess: member checked first
    with pytest.raises(ValueError):
        delivery_fee(101, True)


def test_eg3_negative_and_huge_quantities():      # guess: only one bound checked
    for quantity in (-1, 10**9):
        with pytest.raises(ValueError):
            delivery_fee(quantity, False)


@pytest.mark.skip(reason="EG4: contract silent on bool quantity; ask the owner")
def test_eg4_bool_quantity():
    delivery_fee(True, False)
