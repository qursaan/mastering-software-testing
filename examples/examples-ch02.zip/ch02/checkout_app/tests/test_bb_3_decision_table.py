"""Technique 3: decision table D1-D4 (one row per rule)."""
import pytest

from checkout.fees import delivery_fee

REJECT = "reject"

#  rule, quantity, member, required result
RULES = [
    ("D1", 0, True, REJECT),   # invalid quantity: membership does not matter
    ("D2", 1, True, 0),        # valid member: free
    ("D3", 9, False, 500),     # valid non-member below 10: standard fee
    ("D4", 10, False, 0),      # valid non-member at least 10: free
]


@pytest.mark.parametrize("rule, quantity, member, expected", RULES,
                         ids=[r[0] for r in RULES])
def test_decision_rule(rule, quantity, member, expected):
    if expected == REJECT:
        with pytest.raises(ValueError):
            delivery_fee(quantity, member)
    else:
        assert delivery_fee(quantity, member) == expected
