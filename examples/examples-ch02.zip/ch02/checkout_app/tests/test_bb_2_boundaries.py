"""Technique 2: boundary-value analysis (limit and both neighbours)."""
import pytest

from checkout.fees import delivery_fee


@pytest.mark.parametrize("quantity, expected", [
    pytest.param(1, 500, id="T02-lower-limit"),
    pytest.param(2, 500, id="T03-lower-inside"),
    pytest.param(9, 500, id="T04-below-threshold"),
    pytest.param(10, 0, id="T05-threshold"),
    pytest.param(11, 0, id="T06-above-threshold"),
    pytest.param(99, 0, id="T07-upper-inside"),
    pytest.param(100, 0, id="T08-upper-limit"),
])
def test_valid_boundaries_for_non_member(quantity, expected):
    assert delivery_fee(quantity, False) == expected


@pytest.mark.parametrize("quantity", [
    pytest.param(0, id="T01-below-lower-limit"),
    pytest.param(101, id="T09-above-upper-limit"),
])
def test_invalid_boundaries_are_rejected(quantity):
    with pytest.raises(ValueError):
        delivery_fee(quantity, False)
