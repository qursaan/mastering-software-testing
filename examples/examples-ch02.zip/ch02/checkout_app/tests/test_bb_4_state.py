"""Technique 4: state-transition testing for R3 (per request ID)."""
import pytest

from checkout.service import CheckoutService


@pytest.fixture
def service():
    return CheckoutService()          # fresh state for every test


def test_st1_new_to_ordered(service):
    service.submit("req-1", 2, False)
    assert len(service.orders) == 1 and service.charges == ["req-1"]


def test_st2_repeat_stays_ordered_without_new_charge(service):
    first = service.submit("req-1", 2, False)
    again = service.submit("req-1", 2, False)
    assert again == first
    assert len(service.orders) == 1 and service.charges == ["req-1"]


def test_st3_invalid_submit_stays_new(service):
    with pytest.raises(ValueError):
        service.submit("req-1", 0, False)
    assert service.orders == {} and service.charges == []


def test_st4_new_id_is_a_separate_order(service):
    service.submit("req-1", 2, False)
    service.submit("req-2", 2, False)
    assert service.charges == ["req-1", "req-2"]
