"""Technique 1: equivalence partitioning (one representative per class)."""
import pytest

from checkout.fees import delivery_fee

# Quantity classes P1-P4 and membership classes M1-M2 from Chapter 2.


def test_p1_below_range_is_rejected():
    with pytest.raises(ValueError):
        delivery_fee(-5, False)


def test_p2_small_order_pays_500():
    assert delivery_fee(5, False) == 500


def test_p3_large_order_is_free():
    assert delivery_fee(50, False) == 0


def test_p4_above_range_is_rejected():
    with pytest.raises(ValueError):
        delivery_fee(250, False)


def test_m2_member_small_order_is_free():
    assert delivery_fee(5, True) == 0
