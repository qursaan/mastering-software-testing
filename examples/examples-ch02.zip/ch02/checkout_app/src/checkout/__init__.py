"""Teaching checkout package for Chapter 2."""
