"""Checkout service for R3: one order and one charge per request ID."""

from checkout.fees import delivery_fee


class CheckoutService:
    def __init__(self):
        self.orders = {}    # request_id -> stored order
        self.charges = []   # payment ledger, as a provider test double would record it

    def submit(self, request_id, quantity, member):
        if request_id in self.orders:          # repeat: return the stored order
            return self.orders[request_id]
        fee = delivery_fee(quantity, member)   # R1: reject before any side effect
        order = {"id": request_id, "quantity": quantity, "fee": fee}
        self.orders[request_id] = order
        self.charges.append(request_id)
        return order
