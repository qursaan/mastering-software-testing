"""Lab 4, random: reproducible tests with an oracle by construction (T4.1, ...)."""
import random

import pytest

from tickets.refund import refund

SEED = 4  # record the seed you used in your report


def generate(n=10, seed=SEED):
    """Yield (id, price, days_before, member, expected) rows."""
    rng = random.Random(seed)
    # TODO: for each test, pick the expected kind of refund first (full,
    # half, nothing), then member, then price and days_before from a range
    # that must give that kind. Compute expected from L6, not from refund().
    return []


ROWS = list(generate())


@pytest.mark.parametrize("price, days_before, member, expected",
                         [r[1:] for r in ROWS], ids=[r[0] for r in ROWS])
def test_random(price, days_before, member, expected):
    assert refund(price, days_before, member) == expected
