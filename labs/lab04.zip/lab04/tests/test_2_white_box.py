"""Lab 4, white-box: add only the tests your coverage analysis shows are missing."""
import pytest

from tickets.refund import refund

# TODO: for each white-box item the black-box tests do not cover, add one
# test and name the item (SC, BC, CC, MCDC, P, DU) in the test name.
