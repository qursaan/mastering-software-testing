"""Lab 4, black-box: EP, BV and truth-table tests. One id per test (T1.1, ...)."""
import pytest

from tickets.refund import refund

# TODO: list the partitions, boundaries and truth-table rules as comments,
# then add one row per test. Expected values come from L6 only.
# Worked example: T1.1 covers the full-refund partition (7 or more days),
# a non-member, and the result "full price". L6 gives 1000 before any run.
CASES = [  # id, price, days_before, member, expected (from L6)
    ("T1.1", 1000, 10, False, 1000),
]


@pytest.mark.parametrize("price, days_before, member, expected",
                         [c[1:] for c in CASES], ids=[c[0] for c in CASES])
def test_refund(price, days_before, member, expected):
    assert refund(price, days_before, member) == expected

# TODO: error tests go in their own test with pytest.raises(ValueError),
# one invalid input per test.
