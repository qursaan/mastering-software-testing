"""Lab 4 refunds. Test it against contract L6, not against this code."""


def refund(price, days_before, member=False):
    """Return the refund in cents for a cancelled ticket.

    L6: price must be at least 1 cent and days_before at least 0, else
        ValueError. The refund is the full price when the ticket is
        cancelled 7 or more days before the show, or when a member cancels
        2 or more days before. Otherwise it is half the price, rounded down,
        for 2 to 6 days before, and nothing for 0 or 1 day before.
    """
    if price < 1:
        raise ValueError("price must be at least 1 cent")
    refund_value = 0
    if days_before > 7 or (member and days_before >= 2):
        refund_value = price
    elif days_before >= 2:
        refund_value = price // 2
    return refund_value
