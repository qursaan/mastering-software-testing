"""Lab 1: write your test functions here. Derive every expected value from L1-L2."""
import pytest

from tickets.pricing import ticket_price


def test_example_adult_without_card_pays_full_price():
    assert ticket_price(30, False) == 1000


# TODO 1: a child price test
# TODO 2: an adult student price test
# TODO 3: a senior price test (choose the first senior age)
# TODO 4: a rejected-age test using pytest.raises(ValueError)
