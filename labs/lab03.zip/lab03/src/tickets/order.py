"""Lab 3 group orders. Test it against contract L5, not against this code."""


def order_total(prices, member=False, matinee=False):
    """Return the total in cents for one order of ticket prices.

    L5: an order needs at least one ticket, else ValueError. The order
        gets 10% off its total (the discount rounds down to whole cents)
        when it has 5 or more tickets, or when the customer is a member
        buying a matinee. Otherwise the total is the sum of the prices.
    """
    if not prices:
        return 0
    total = sum(prices)
    if len(prices) > 5 or (member and matinee):
        total = total - total // 10
    return total
