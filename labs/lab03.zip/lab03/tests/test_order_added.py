"""Lab 3: your tests. Give each one a coverage-item id (SC, BC, MCDC, BV, MUT)."""
import pytest

from tickets.order import order_total

# TODO: one test per missed item from the coverage report, one per MC/DC
# pair, and the boundary test that kills the given mutant. Expected values
# come from L5 only.


def test_mcdc_1_member_matinee():
    """Worked example. MCDC-1: 2 tickets, member, matinee.

    L5: a member buying a matinee gets 10% off 1800, so 1800 - 180 = 1620.
    It forms the member pair with MCDC-2 (same order, member=False).
    """
    assert order_total([1000, 800], member=True, matinee=True) == 1620
