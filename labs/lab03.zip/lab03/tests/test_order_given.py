"""Lab 3: the given tests. Run them under coverage before adding your own."""
from tickets.order import order_total


def test_small_order_pays_full_price():
    assert order_total([1000, 800]) == 1800


def test_large_order_gets_ten_percent_off():
    assert order_total([1000] * 6) == 5400
