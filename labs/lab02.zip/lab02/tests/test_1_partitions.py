"""Lab 2, technique 1: partitions. Name each test after its coverage item."""
import pytest

from tickets.booking import TicketBooking
from tickets.pricing import ticket_price

# TODO: list your coverage items as comments, then write one test (or one
# parametrize row) per item. Expected values come from L1-L4 only.
