"""Cinema ticket package for the labs."""
